<?php 
 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
$config['mode'] = 'sandbox';
 
/**
* Account SID
**/
// $config['account_sid'] = 'Your account sid that are acess from twilio dashboard';
// $config['account_sid'] = 'SK774079d358aef6c0f277d681479c2367';
$config['account_sid'] = 'AC0a1483128770f47827c5c78a09aa6628';
 
/**
* Auth Token
**/
// $config['auth_token'] = 'Your Authentication acess from twilio dashboard';
// $config['auth_token'] = 'OXiyqLwnCDtHW4fuawVrx9OV7ohVlZEU';
$config['auth_token'] = 'd56b83bce70fd8227491bfa284dce7cf';
 
/**
* API Version
**/
$config['api_version'] = '2010-04-01';
 
/**
* Twilio Phone Number
**/
// $config['number'] = 'Your configuration no that you have need to set in twilio dashboard is used to send recive message';
// $config['number'] = '+91 8190023811';
$config['number'] = ' +16148082075';
 
/* End of file twilio.php */
?>